import { initializeApp } from 'firebase/app';

const firebaseConfig = {
  apiKey: "AIzaSyARxORC9DvKPJLv5RCo1Fr01qctPi2mn6A",
  authDomain: "labawebnew3.firebaseapp.com",
  projectId: "labawebnew3",
  storageBucket: "labawebnew3.appspot.com",
  messagingSenderId: "153391404970",
  appId: "1:153391404970:web:e9ae0d14d036dd3d5abdd3"
};

const app = initializeApp(firebaseConfig);

export default app;
