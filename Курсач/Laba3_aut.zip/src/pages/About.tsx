import React from 'react';
import Header from '../components/Header';

const AboutPage = () => {
  return (
    
    <div>
        <Header /> {/* Используем компонент шапки */}
      <p>Этот курсовой проект сделали Белявский Николай Константинович и Чувилин Максим Сергеевич 221-373</p>
      <p>Это реализация интернет магазина</p>
    </div>
  );
};

export default AboutPage;
